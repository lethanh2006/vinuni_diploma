# @vinuni/ui

Thư viện UI dùng chung cho các dự án web của VinUni: component React, design
token lấy từ Figma, theme sáng/tối, motion và hạ tầng overlay.

Publish lên registry npm nội bộ trên JFrog, **không** có trên npmjs.org. Mã nguồn
ở [`vinuni-ui`](https://gitlab.vinsmartfuture.tech/vsf-qtvhgd/vinuni/shared/vinuni-ui)
trên GitLab nội bộ.

Mục tiêu: dự án khác chỉ cần thêm một dòng vào `package.json` rồi dùng. Phần duy
nhất phải làm thêm một lần là trỏ scope `@vinuni` về JFrog — npm mặc định đi tìm
ở npmjs.org và sẽ trả 404.

> Sửa chính thư viện chứ không phải dùng nó?
> Xem [CONTRIBUTING.md](./CONTRIBUTING.md).

---

## Icon micro animation

Mọi component SVG `Icon*` hỗ trợ `animate` (mặc định `false`) và `active`:

```tsx
<Button icon={<IconBell animate />}>Thông báo</Button>
<IconButton label="Yêu thích" aria-pressed={saved} onClick={() => setSaved(!saved)}>
  <IconHeart animate active={saved} />
</IconButton>
<IconStar animate={false} />
```

Hover cả vùng nút để chạy một nhịp; nhấn để có phản hồi co nhẹ. `active` chạy
một nhịp khi chuyển sang `true` (kể cả lúc mount), không lặp liên tục. Icon đang
active vẫn phản hồi hover. Với wrapper tùy chỉnh, thêm `data-icon-trigger`.

CSS dùng chung, không thêm thư viện animation hay cập nhật React theo frame;
giữ nguyên bản vẽ quang học 16/24px. Toàn bộ 203 icon được gán vào 23 nhóm
chuyển động theo ý nghĩa: điều hướng, gửi, sách, chat, công cụ, mắt, thể thao,
xác nhận… Storybook `Foundations/Icons/Animated Gallery` cho phép tìm và thử
từng icon ở 16/24px. Story `Foundations/Icons/Micro Animation` trình bày 23
nhóm với icon đại diện, cỡ 16/24/32px và ví dụ sử dụng tương tác. Tự tắt khi reduced motion hoặc
control bị disabled. Chuyển động áp dụng lên glyph có sẵn, không morph từng nét.
`MaskIcon` và `FileTypeIcon` không thuộc API này.

## Cài vào một dự án mới

### 1. Trỏ scope `@vinuni` về JFrog

Tạo `.npmrc` ở **gốc repo** và **commit nó**:

```
@vinuni:registry=https://jfrog.vinsmartfuture.tech/artifactory/api/npm/vsf-qtvhgd-vinuni/
```

File này không chứa credential và không được phép chứa. Nó chỉ nói cho npm biết
tìm `@vinuni/*` ở đâu; phần xác thực đến từ chỗ khác (bước 2). Nếu `.gitignore`
của bạn chặn `.npmrc` thì thêm ngoại lệ cho file gốc:

```gitignore
.npmrc
!/.npmrc
```

### 2. Đưa token vào máy dev

Token nằm ở `~/.npmrc` của từng người, **không** nằm trong repo:

```
//jfrog.vinsmartfuture.tech/artifactory/api/npm/vsf-qtvhgd-vinuni/:_authToken=<token>
```

npm gộp config của project và của user, nên chỉ cần dòng registry trong repo và
dòng token ở `~/.npmrc` là `npm install` chạy được.

Lấy token: đăng nhập <https://jfrog.vinsmartfuture.tech> → *Edit Profile* →
*Generate an Identity Token*. Cần quyền **Read** trên repo `vsf-qtvhgd-vinuni`.
Kiểm nhanh:

```bash
npm whoami --registry=https://jfrog.vinsmartfuture.tech/artifactory/api/npm/vsf-qtvhgd-vinuni/
```

### 3. Cài

```bash
npm install @vinuni/ui         # bản release mới nhất (dist-tag `latest`)
```

Không cần cài thêm gì. Radix, cmdk, vaul, tailwind-merge… là `dependencies` của
thư viện nên npm tự kéo về. Yêu cầu duy nhất từ phía host là peer dependency:

```
react     >=18.2.0 <20
react-dom >=18.2.0 <20
```

### 4. Nối vào app

```tsx
import '@vinuni/ui/styles.css'   // trước stylesheet của app
import './app.css'
import { Button, UiProvider } from '@vinuni/ui'

export function App() {
  return (
    <UiProvider defaultTheme="system">
      <Button>Tiếp tục</Button>
    </UiProvider>
  )
}
```

Hai thứ bắt buộc: import `styles.css` **một lần** ở entry point, và bọc phần cây
React có dùng component trong `UiProvider`. Provider giữ theme
`light`/`dark`/`system` và portal host cục bộ. Component nào cần portal (dialog,
dropdown, popover, sheet, tooltip, select, drawer, toast) mà nằm ngoài provider
sẽ ném thẳng `useUi must be used within a UiProvider` — lỗi rõ ràng, không phải
kiểu hỏng âm thầm.

`defaultTheme` mặc định đã là `"system"`, truyền vào chỉ khi muốn ép
`"light"`/`"dark"`.

Xong. Từ đây `import { … } from '@vinuni/ui'` là dùng được.

### 5. (Nên làm) Bật skill cho agent

Thư viện ship kèm một skill cho coding agent. Trỏ agent vào nó một lần thì
Claude Code, Cursor… biết sẵn cách nối provider, chọn variant, và xử lý va chạm
CSS với design system khác — thay vì đoán:

```bash
mkdir -p .claude/skills
ln -s ../../node_modules/@vinuni/ui/skills/vinuni-ui .claude/skills/vinuni-ui
```

Symlink chứ không copy: skill đi theo đúng version `@vinuni/ui` đang cài, nâng
version là skill tự cập nhật. Nội dung xem ở
[`skills/vinuni-ui/SKILL.md`](./skills/vinuni-ui/SKILL.md).

---

## Đặt cạnh design system khác

CSS của thư viện build với scope `:where([data-vinuni-ui])` và độ ưu tiên bằng 0.
Nó không ghi vào `:root`, `html`, `body` hay class `.dark` toàn cục, nên đặt cạnh
một Tailwind host, Ant Design hay design system khác đều không rò rỉ.

Nạp stylesheet của app **sau** stylesheet của thư viện thì class thường của bạn
ghi đè được mặc định của component, không cần prop riêng và không cần
`!important`:

```tsx
<Button className="w-full rounded-none">Tiếp tục</Button>
```

Dùng variant cho lựa chọn ngữ nghĩa mà thư viện đã định nghĩa; dùng `className`
cho layout và phần trình bày thuộc về màn hình đang viết.

### Host dùng Ant Design

`antd/dist/reset.css` **không** nằm trong `@layer` nào. Toàn bộ CSS của thư viện
thì có (output Tailwind v4). Theo cascade CSS, declaration không layer luôn
thắng declaration có layer bất kể specificity — nên reset của antd sẽ đè lên
component của thư viện, và **đổi thứ tự import không cứu được**.

Import reset vào một layer đăng ký trước:

```css
/* antd-reset.css */
@import "antd/dist/reset.css" layer(antd-reset);
```

```tsx
import './antd-reset.css'        // đăng ký layer đầu tiên → ưu tiên thấp nhất
import '@vinuni/ui/styles.css'
import './app.css'
```

Kiểm bằng cách xem CSS build ra: phải bắt đầu bằng `@layer antd-reset{…}` rồi
mới tới `@layer properties/theme/base/components/utilities` của Tailwind.

Style component của antd (cssinjs, inject lúc runtime) cũng không layer, nhưng
đều bọc `.ant-*` nên hiếm khi va. Muốn chắc thì dùng `<StyleProvider layer>` của
`@ant-design/cssinjs`.

### Host dùng Tailwind v3

Không cần cấu hình gì. Thư viện ship CSS đã build và đã scope — đừng thêm
`node_modules/@vinuni/ui` vào `content`, đừng đặt prefix.

### Host dùng Tailwind v4

Nếu app tự viết class `ds-*` (`bg-ds-bg-grounded`, `p-ds-sp-16`,
`rounded-ds-rd-primary`…) thì import thêm file này trong CSS entry của Tailwind:

```css
@import "@vinuni/ui/tokens.css";
@import "@vinuni/ui/tailwind-theme.css";
```

`tailwind-theme.css` chỉ đăng ký alias token để Tailwind sinh ra utility tương
ứng; nó không thêm style runtime nào. Component của thư viện không cần file này.

### Font

Mặc định thư viện giữ đúng font của design (`Geist Variable`,
`Merriweather Variable`, `Roboto Slab Variable`). Host đổi được trong phạm vi
provider mà không đụng style toàn cục:

```css
[data-vinuni-ui] {
  --vinuni-font-sans: "Inter Variable", Inter, sans-serif;
  --vinuni-font-heading: "Inter Variable", Inter, sans-serif;
  --vinuni-font-serif: "Source Serif 4", serif;
}
```

Đừng đặt thẳng `--font-sans`: nó được sinh ra *từ* ba hook trên, ghi đè ngược
lại sẽ thành tham chiếu vòng.

Hai cái bẫy hay gặp:

- Bất kỳ phần tử nào **bên trong** scope mà khai lại `font-family` (một class
  layout của app chẳng hạn) sẽ trở thành ancestor gần nhất và thay font của mọi
  component chỉ kế thừa — 26/49 component cố ý không tự đặt font. Nếu font đúng
  ở chỗ này mà sai ở chỗ kia, tìm cái wrapper đó trước khi nghi thư viện.
- Tên family phải đúng cái mà font package đăng ký:
  `@fontsource-variable/inter` đăng ký `'Inter Variable'`, không phải `'Inter'`.

### Entry point có sẵn

| Import | Nội dung |
| --- | --- |
| `@vinuni/ui` | Barrel — component, hook, type |
| `@vinuni/ui/styles.css` | Toàn bộ CSS runtime (đã gồm motion) |
| `@vinuni/ui/tokens.css` | Chỉ biến `--ds-*` |
| `@vinuni/ui/tailwind-theme.css` | Alias token cho Tailwind v4 |
| `@vinuni/ui/motion.css` | Chỉ motion, khi không dùng `styles.css` |
| `@vinuni/ui/provider` · `/utils` · `/hooks/*` | Deep import |
| `@vinuni/ui/button` | Deep import từng component |

---

## CI và Docker

Đây là chỗ hay vỡ nhất: máy dev chạy được vì có `~/.npmrc`, còn container thì
không có gì cả và `npm ci` trả `E401`.

### Docker

```dockerfile
FROM node:22-alpine AS dependencies
WORKDIR /app
ARG JFROG_NPM_TOKEN
COPY package.json package-lock.json .npmrc ./
RUN if [ -z "${JFROG_NPM_TOKEN}" ]; then \
      echo "Thiếu build-arg JFROG_NPM_TOKEN — npm ci sẽ 401 ở @vinuni/*." >&2; \
      exit 1; \
    fi; \
    printf '//jfrog.vinsmartfuture.tech/artifactory/api/npm/vsf-qtvhgd-vinuni/:_authToken=%s\n' \
      "${JFROG_NPM_TOKEN}" >> .npmrc \
    && npm ci \
    && rm -f .npmrc
```

Ghi và xoá token trong **cùng một `RUN`**. Tách thành hai layer thì token nằm lại
ở layer trung gian và `docker history` đọc được, kể cả khi layer sau đã xoá file.

Nhớ kiểm `.dockerignore` không loại `.npmrc` — loại thì `COPY` sẽ fail.

### GitLab CI

Job build phải truyền `JFROG_NPM_TOKEN` xuống làm build-arg. Với component
`dockerize` của centralize-ci-templates:

```yaml
- component: gitlab.vinsmartfuture.tech/shared/vsf-ptnt/centralize-ci-templates/dockerize@v2.3.0
  inputs:
    build_args: "--opt build-arg:JFROG_NPM_TOKEN=${JFROG_NPM_TOKEN}"
```

`build_args` là **input của component**, chỉ set được ở nơi khai báo `include`.
Nếu dự án của bạn include một template dùng chung ở `gitops-dev` mà template đó
chưa truyền build-arg này thì phải sửa ở `gitops-dev`, không override được từ
repo tiêu thụ.

Job nào chạy `npm ci` ngoài Docker (test, coverage, lint) cũng cần `.npmrc` có
token — dựng nó trong `before_script` rồi xoá ở `after_script`.

---

## Version

| Cài | Nhận được |
| --- | --- |
| `@vinuni/ui` | Bản release mới nhất, dist-tag `latest` |
| `@vinuni/ui@1.2.3` | Đúng version đó |

Chỉ có một kênh phát hành: mọi version trên registry đều là bản chính thức với
dist-tag `latest` — không còn dist-tag `sit` hay `dev`. Dự án production nên pin
`^1.2.3` và bump có chủ đích.

Thay đổi nhìn thấy được từ phía consumer nằm ở [CHANGELOG.md](./CHANGELOG.md).
Bản nào có breaking thì kèm một hướng dẫn theo bước trong `docs/migration/`:

- [`0.1.0` → `0.1.1`](./docs/migration/0.1.0-to-0.1.1.md) — gỡ `LiquidView` /
  `LiquidLayers`, thu hẹp prop của `LiquidButton` và `ScrollEdgeEffect`, và một
  loạt component **đổi diện mạo mà không báo lỗi gì**. Chụp ảnh màn hình trước
  khi nâng.

---

## Troubleshooting

| Triệu chứng | Nguyên nhân |
| --- | --- |
| `404 Not Found - GET https://registry.npmjs.org/@vinuni%2fui` | Thiếu dòng `@vinuni:registry=…` trong `.npmrc`. npm đang tìm ở npmjs.org |
| `npm error code E401` | Không có token, token sai hoặc hết hạn. Kiểm bằng `npm whoami --registry=…` |
| `npm error code E403` | Token xác thực được nhưng thiếu quyền trên `vsf-qtvhgd-vinuni` |
| `E401` chỉ xảy ra trong Docker/CI | Container không có `~/.npmrc`. Xem mục CI và Docker ở trên |
| Component render nhưng không có style | Quên `import '@vinuni/ui/styles.css'` ở entry point, hoặc cây React nằm ngoài `UiProvider` |
| Style có tác dụng nhưng utility của app không đè được | Stylesheet của app đang import **trước** của thư viện |
| Style vỡ sau khi thêm design system khác | Design system đó ship reset không layer (thường là Ant Design). Xem mục "Đặt cạnh design system khác" |
| `useUi must be used within a UiProvider` | Component cần portal đang nằm ngoài `UiProvider` |
| Overlay hiện ra nhưng không có token/theme | Có `UiProvider` nhưng render overlay vào container tự cấp; truyền `portalContainer` cho provider thay vì portal thủ công |
| Class `ds-*` do app tự viết không có tác dụng | Thiếu `@import "@vinuni/ui/tailwind-theme.css"` (chỉ Tailwind v4) |
| Chữ ra font hệ thống thay vì font design | Có phần tử bên trong scope khai lại `font-family`, hoặc tên family sai (xem mục Font) |
