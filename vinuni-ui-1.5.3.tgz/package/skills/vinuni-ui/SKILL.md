---
name: vinuni-ui
description: Use when building UI in a project that depends on @vinuni/ui — the VinUni React component library. Covers wiring the provider and stylesheet, picking a component and its variants, theming, icons, and coexisting with an existing design system (Ant Design, Tailwind, MUI). Triggers on @vinuni/ui, VinUniProvider, UiProvider, "the VinUni components", "styles.css not applying", "overlay renders unstyled", or any import from @vinuni/ui.
---

# Using @vinuni/ui

A React component library whose defining property is that **its CSS cannot leak
into the host app, and the host's CSS cannot reach inside it** — except through
one deliberate escape hatch. Most mistakes come from not knowing which of those
two directions you are fighting.

## Three things that must be true, or nothing works

**1. `styles.css` is imported exactly once, at the app entry, before the app's
own stylesheet.**

```tsx
import '@vinuni/ui/styles.css'   // package first
import './app.css'               // app second
```

Order is not cosmetic. Every package selector is wrapped in
`:where([data-vinuni-ui])`, which has **zero specificity** — that is what lets an
ordinary `className` from the app override a component default without
`!important`. Zero specificity only wins ties by source order, so the package
must come first.

**2. Everything using a component sits inside `UiProvider`.**

```tsx
import { Button, UiProvider } from '@vinuni/ui'

<UiProvider defaultTheme="system">
  <Button>Continue</Button>
</UiProvider>
```

The provider renders the `data-vinuni-ui` scope attribute (without it, *no*
package CSS matches), the `data-vinuni-theme` attribute, and a portal host div.

**3. Overlays portal into the provider, not `document.body`.**

`advanced-select`, `date-picker`, `date-range-picker`, `dialog`, `drawer`, `dropdown-menu`, `popover`, `select`,
`sheet`, `sonner`, and `tooltip` already do this internally. A component that
needs the portal and is
mounted outside the provider throws
`useUi must be used within a UiProvider` — a loud failure, not a silent one.
If you portal something yourself, use the provider's container:

```tsx
const { portalContainer } = useUi()
```

or wrap the children in the exported `<UiPortal>`.

**`FileUploadField` needs a second provider.** It uploads over HTTP, and the
package refuses to guess where your storage lives or how you authenticate:

```tsx
import { createFileManagerClient, FileManagerProvider, UiProvider } from '@vinuni/ui'

const fileManager = createFileManagerClient({
  baseUrl: import.meta.env.VITE_FILE_MANAGER_API_URL,
  httpClient: myAuthedFetch,   // or: getToken: () => auth.accessToken
})

<UiProvider>
  <FileManagerProvider client={fileManager}>{children}</FileManagerProvider>
</UiProvider>
```

`FileManagerProvider` does **not** replace `UiProvider` — they are independent,
and an app that never uploads a file never needs it. Pass `httpClient` when your
app already has an HTTP layer that refreshes tokens and retries 401; the package
deliberately does not implement that itself. Pass `getToken` only when a plain
bearer token is the whole story. Missing both the provider and the `client`
prop throws a message naming `FileManagerProvider`.

See `references/components.md` § File upload for the field itself.

**`MessageScroller` needs its own provider too.** Scroll state (turn anchoring,
follow-the-live-edge, history preservation) lives in
`MessageScrollerProvider`, which wraps the frame:

```tsx
<MessageScrollerProvider autoScroll>
  <MessageScroller>…</MessageScroller>
</MessageScrollerProvider>
```

It is not a replacement for `UiProvider` — you still need that outside. The
`useMessageScroller*` hooks throw if called outside it.

## className vs variant

Both are correct, for different things:

- **`variant` / `size`** — a semantic choice the library has already defined
  (`<Button variant="destructive" size="lg">`). Use these first.
- **`className`** — layout and presentation belonging to the screen you are
  writing (`<Button className="w-full rounded-none">`).

Do **not** reach for `!important`, a wrapper div with `>` selectors, or a new
prop when a `className` would do. The zero-specificity scope was built so
`className` just works.

One surprise: `cn()` can keep *both* a `ds-*` class and a standard one
(`h-ds-size-button-md` alongside `h-auto`) because tailwind-merge does not know
the custom theme keys are the same group. That is usually fine — the app's rule
wins on source order — but it is why the emitted class list sometimes looks
redundant.

## Theme

Light/dark is keyed off `data-vinuni-theme` on the provider, **not** a global
`.dark` class. A host's `.dark` has no effect inside the scope, and vice versa.

```tsx
<UiProvider theme={theme} onThemeChange={setTheme}>   // controlled
<UiProvider defaultTheme="dark">                       // uncontrolled
```

`defaultTheme` is already `"system"`; pass it only to force a mode. Read the
current mode with `useUi()` (requires a provider) or `useResolvedTheme()` (falls
back to `'light'` without one).

Color tokens are also available as JavaScript: `colors.contentPrimary` is a
`var()` reference for inline styles inside the provider, while
`useColorValues()` returns real hex/rgb values for things that cannot read CSS
variables — Ant Design's `ConfigProvider`, charts, canvas. See
`references/setup.md` → "Colors in JavaScript".

## Contrast floors for the semantic tokens

`--ds-{positive,negative,critical,informative}-primary` are **accent colours,
not text colours.** On a light surface they land at 2.96–4.33:1, and on their
own `-secondary` chip at 2.53–4.79:1 — under the 4.5:1 that WCAG 1.4.3 asks for
text below 18.66px bold / 24px regular. Measured (light / dark, on
`bg-elevated`):

| token | on surface | on its `-secondary` chip |
| --- | --- | --- |
| `positive-primary` | 2.96 / 7.73 | 2.53 / 4.99 |
| `negative-primary` | 4.33 / 3.69 | 3.62 / 3.32 |
| `critical-primary` | 3.19 / 7.87 | 2.68 / 5.71 |
| `informative-primary` | 6.01 / 4.84 | 4.79 / 3.76 |

So in product code:

- **Label text** takes `text-ds-content-primary` (15–16:1 light, 11.5–16:1 dark
  on those chips). Carry the state in an **icon** tinted with the semantic
  token — an icon is non-text, so its floor is 3:1, and it also stops colour
  from being the only channel.
- `<Badge variant="complete" | "warning" | "negative" | "destructive" |
  "inprogress">` already does this internally; do not push the semantic colour
  back onto its label with `className`.
- Never reach for `text-ds-*-primary` on 12–14px copy (validation lines, table
  cells, captions). It reads correct in Figma and fails the contrast check.

Focus indicators use `ring-ring`, which resolves to `accent-primary` in light
and `brand-accent-blue-vivid` in dark (7.65:1 / 4.45:1 — WCAG 1.4.11 wants 3:1).
`accent-primary` is the *same* navy in both themes and only reaches 2.09:1 on a
dark surface, so do not hard-code `ring-ds-accent-primary` or
`ring-ds-accent-tertiary` for focus.

## Icons

Import `Icon*` components from the barrel — the package ships 205 of them with
two-tier optical sizing (a purpose-drawn 16px master swaps in at `size <= 16`).

```tsx
import { IconCheck, IconMagnifyingglass, FileTypeIcon } from '@vinuni/ui'
```

Every `Icon*` also takes `animate` (opt in, default `false`) and `active` for a
short micro motion on hover/press — see `references/components.md` → Icons.

```tsx
<Button icon={<IconBell animate />}>Notifications</Button>
<IconHeart animate active={saved} />
```

Do not add `lucide-react`, `@hugeicons/*`, or an `<img>` for an icon in a
VinUni-styled surface: a raster or externally-filled SVG freezes its colour
across themes. For a genuine one-off vector, use `<MaskIcon>` (CSS mask +
`currentColor`).

## When something looks wrong

| Symptom | Cause |
| --- | --- |
| Components render but are completely unstyled | Missing `import '@vinuni/ui/styles.css'`, or the tree is outside `UiProvider` (no `data-vinuni-ui` attribute) |
| Styles work, but the host's utilities cannot override them | App stylesheet is imported *before* the package's |
| **Package styles break after adding another design system** | That system ships an unlayered reset (Ant Design's `reset.css` is the common one). Unlayered CSS beats *any* layered CSS regardless of specificity, and all package CSS is layered. See `references/setup.md` → "Coexisting with another design system" |
| Overlay opens but has no theme or tokens | It is being portalled somewhere outside the provider; pass `portalContainer` |
| `useUi must be used within a UiProvider` | A portal-using component is mounted outside the provider |
| App-authored `ds-*` classes do nothing | Tailwind v4 host missing `@import "@vinuni/ui/tailwind-theme.css"` |
| A color from `colors.*` renders transparent or inherited | It is a `var()` reference used outside `[data-vinuni-ui]` (an antd popup, a chart, a canvas). Use `useColorValues()` there |
| A questionnaire step animates the first time and never again | The steps are being conditionally rendered. `Questionnaire` keeps every step mounted and marks the inactive ones `hidden`; that is what drives the CSS transition — and rendering only the active one also throws away the other answers |
| `autoScroll` yanks the transcript back to the bottom when the reader scrolled up by **dragging the scrollbar** | Known `@shadcn/react` limitation: it listens for `wheel` / `touchmove` / arrow keys to detect user scrolling, not `scroll`. Wheel, trackpad, touch and keyboard all behave correctly; only a scrollbar drag is affected |
| The chat transcript jumps to the bottom on every streamed token | `scrollAnchor` is set on every row. It marks a *turn boundary* — set it on the user's message only |
| A `Marker` with `shimmer` shows no sweeping band | The OS is set to reduce motion — the loop is turned off there by design. Keep a spinner in `MarkerIcon` so "running" still reads |
| A labelled `Marker` divider is not announced by a screen reader | `role="separator"` was added. A separator takes its name from `aria-label` and treats its contents as presentational; a labelled divider needs **no** role |
| Text renders in a system font instead of the design font | An ancestor *inside* the scope re-declares `font-family`; 26 of 49 components inherit rather than set it |

## Reference files

Read these on demand — do not preload them.

- **`references/setup.md`** — installing from the private registry, entry-point
  wiring, Docker/CI, coexisting with Ant Design / Tailwind v3 / Tailwind v4,
  fonts, and the full export map.
- **`references/components.md`** — the component inventory with variants, the
  form-field state model, and composition patterns worth copying.
