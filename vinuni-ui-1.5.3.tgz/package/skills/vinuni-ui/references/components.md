# Component reference

Everything below is exported from the barrel: `import { … } from '@vinuni/ui'`.

## Inventory

| Family | Exports |
| --- | --- |
| Accordion | `Accordion`, `AccordionItem`, `AccordionTrigger`, `AccordionContent` |
| AccountMenu | `AccountMenu`, `AccountMenuTrigger`, `AccountMenuOptions`, `AccountMenuItem`, `AccountMenuItemValue`, `AccountMenuSeparator` |
| Advanced select | `AdvancedSelect`, `AdvancedSelectOption`, `AdvancedSelectProps`, `AdvancedSelectSingleProps`, `AdvancedSelectMultipleProps` |
| AiOrb | `AiOrb` |
| Alert | `Alert`, `AlertTitle`, `AlertDescription`, `AlertAction` |
| AppSplash | `AppSplash` |
| Avatar | `Avatar`, `AvatarImage`, `AvatarFallback`, `AvatarBadge`, `AvatarGroup`, `AvatarGroupCount` |
| Badge | `Badge`, `badgeVariants` |
| Breadcrumb | `Breadcrumb`, `BreadcrumbList`, `BreadcrumbItem`, `BreadcrumbLink`, `BreadcrumbPage`, `BreadcrumbSeparator`, `BreadcrumbEllipsis` |
| Button | `Button`, `buttonVariants`, `IconButton`, `LiquidButton`, `liquidButtonVariants` |
| Card | `Card`, `CardHeader`, `CardTitle`, `CardDescription`, `CardAction`, `CardContent`, `CardFooter` |
| Checkbox | `Checkbox`, `checkboxVariants` |
| College ribbon | `CollegeRibbonCas`, `CollegeRibbonCecs`, `CollegeRibbonChs`, `CollegeRibbonCbm`, `CollegeRibbonGallery` |
| Chip | `Chip`, `ChipGroup`, `chipVariants` |
| Command | `Command`, `CommandDialog`, `CommandInput`, `CommandSearchInput`, `CommandList`, `CommandEmpty`, `CommandGroup`, `CommandItem`, `CommandSeparator`, `CommandShortcut` |
| Calendar | `Calendar`, `RangeCalendar`, `CalendarProps`, `RangeCalendarProps` |
| Date picker | `DatePicker`, `DateTimePicker`, `DatePickerProps`, `DateTimePickerProps`, `DateTimeValue` |
| Date range picker | `DateRangePicker`, `DateRange`, `DateRangePickerProps`, `DateTimeRangePickerProps` |
| Confirm dialog | `ConfirmDialog`, `ConfirmDialogTrigger`, `ConfirmDialogContent`, `ConfirmDialogHeader`, `ConfirmDialogTitle`, `ConfirmDialogDescription`, `ConfirmDialogActions`, `ConfirmDialogAction`, `ConfirmDialogCancel`, `ConfirmDialogButtonProps` |
| Dialog | `Dialog`, `DialogTrigger`, `DialogContent`, `DialogHeader`, `DialogSubHeader`, `DialogTitle`, `DialogDescription`, `DialogFooter`, `DialogClose`, `DialogPortal`, `DialogOverlay` |
| Drawer | `Drawer`, `DrawerTrigger`, `DrawerContent`, `DrawerHeader`, `DrawerTitle`, `DrawerDescription`, `DrawerFooter`, `DrawerClose`, `DrawerPortal`, `DrawerOverlay` |
| DropdownMenu | `DropdownMenu`, `DropdownMenuTrigger`, `DropdownMenuContent`, `DropdownMenuGroup`, `DropdownMenuLabel`, `DropdownMenuItem`, `DropdownMenuCheckboxItem`, `DropdownMenuRadioGroup`, `DropdownMenuRadioItem`, `DropdownMenuSeparator`, `DropdownMenuShortcut`, `DropdownMenuSub`, `DropdownMenuSubTrigger`, `DropdownMenuSubContent`, `DropdownMenuPortal` |
| Emoji | `LecxeEmojiWeary`, `LecxeEmojiWorried`, `LecxeEmojiNeutral`, `LecxeEmojiSmiling`, `LecxeEmojiStarstruck`, `LecxeEmojiGallery` |
| FileUploader | `FileUploader`, `FileUploaderDropzone`, `FileUploaderList`, `FileUploaderItem`, `FileUploaderIcon`, `FileUploaderError`, `formatFileSize` |
| File upload | `FileUploadField`, `FileManagerProvider`, `useFileManager`, `useFileUpload`, `createFileManagerClient`, `validateUploadFile`, `getFileExtension`, `defaultFileUploadLabels`, `mergeFileUploadLabels`, `fileScopes`, `FileManagerUploadError` |
| Floated surfaces | `FloatedSurface`, `FloatedPanel` |
| Icons | 205 `Icon*` components, `FileTypeIcon`, `MaskIcon`, `createIcon` |
| Input | `Input`, `inputVariants`, `isInvalid`, `resolveFieldState`, `Textarea`, `Label`, `SearchInput`, `searchInputVariants` |
| InputGroup | `InputGroup`, `InputGroupAddon`, `InputGroupButton`, `InputGroupText`, `InputGroupInput`, `InputGroupTextarea` |
| Logo | `Logo`, `LogoMark` |
| Lecxe resources | `LecxeEmpty404`, `LecxeEmptyNoInternet`, `LecxeEmptyNoData`, `LecxeEmptyNoPermission`, `LecxeCustomer`, `LecxeCheckmail`, `LecxeProgramming`, `LecxeCelebrate`, `LecxeApologize`, `LecxeConcern`, `LecxeConcernLocation`, `LecxeSurvey`, `LecxeStudentCard`, `LecxeIphoneApp`, `LecxeRocket`, `LecxeResourceGallery` |
| Messages | `MessageCard`, `MessageToast`, `Toaster`, `messageToast` |
| Chat message | `Message`, `MessageGroup`, `MessageAvatar`, `MessageContent`, `MessageHeader`, `MessageFooter` |
| Chat bubble | `Bubble`, `BubbleGroup`, `BubbleContent`, `BubbleReactions`, `bubbleVariants`, `bubbleReactionsVariants` |
| Chat scroller | `MessageScrollerProvider`, `MessageScroller`, `MessageScrollerViewport`, `MessageScrollerContent`, `MessageScrollerItem`, `MessageScrollerButton`, `useMessageScroller`, `useMessageScrollerScrollable`, `useMessageScrollerVisibility` |
| Chat marker | `Marker`, `MarkerIcon`, `MarkerContent`, `markerVariants` |
| NavigationMenu | `NavigationMenu`, `NavigationMenuList`, `NavigationMenuItem`, `NavigationMenuTrigger`, `NavigationMenuContent`, `NavigationMenuLink`, `NavigationMenuIndicator`, `NavigationMenuViewport` |
| Overlay | `Overlay`, `overlayVariants` |
| Pagination | `Pagination`, `PaginationContent`, `PaginationItem`, `PaginationLink`, `PaginationPrevious`, `PaginationNext`, `PaginationEllipsis` |
| Progress | `Progress`, `ProgressProps` |
| Spinner | `Spinner`, `SpinnerProps` |
| Stepper | `Stepper`, `StepperItem`, `StepperItemStatus`, `StepperProps` |
| Questionnaire | `Questionnaire`, `QuestionnaireProgress`, `QuestionnaireItem`, `QuestionnaireTitle`, `QuestionnaireDescription`, `QuestionnaireChoices`, `QuestionnaireChoice`, `QuestionnaireChoiceDescription`, `QuestionnaireInput`, `QuestionnaireError`, `QuestionnaireActions`, `QuestionnairePrevious`, `QuestionnaireSkip`, `QuestionnaireNext`, `QuestionnaireSubmit` |
| Popover | `Popover`, `PopoverTrigger`, `PopoverAnchor`, `PopoverContent`, `PopoverBar`, `PopoverHeader`, `PopoverTitle`, `PopoverDescription` |
| RadioGroup | `RadioGroup`, `RadioGroupItem`, `radioItemVariants` |
| Scroll | `ScrollEdgeEffect`, `scrollEdgeEffectVariants`, `ScrollIndicator`, `ScrollIndicatorSection`, `ScrollIndicatorPosition`, `ScrollIndicatorProps` |
| SegmentedControl | `SegmentedControl`, `SegmentedControlItem`, `SegmentedControlMenu` |
| Select | `Select`, `SelectTrigger`, `SelectValue`, `SelectContent`, `SelectGroup`, `SelectLabel`, `SelectItem`, `SelectSeparator`, `SelectPopover` |
| Selection | `SelectionIndicator` |
| Separator | `Separator` |
| Sheet | `Sheet`, `SheetTrigger`, `SheetContent`, `SheetHeader`, `SheetTitle`, `SheetDescription`, `SheetFooter`, `SheetClose` |
| Sidebar | `SidebarProvider`, `Sidebar`, `SidebarTrigger`, `SidebarRail`, `SidebarInset`, `SidebarBanner`, `SidebarHeader`, `SidebarTitle`, `SidebarContent`, `SidebarFooter`, `SidebarGroup`, `SidebarGroupLabel`, `SidebarGroupAction`, `SidebarGroupContent`, `SidebarCollapsibleGroup`, `SidebarGroupTrigger`, `SidebarGroupCollapsibleContent`, `SidebarMenu`, `SidebarMenuItem`, `SidebarMenuButton`, `SidebarMenuAction`, `SidebarMenuBadge`, `SidebarMenuSkeleton`, `SidebarMenuSub`, `SidebarMenuSubItem`, `SidebarMenuSubButton`, `SidebarInput`, `SidebarSeparator`, `useSidebar`, `useSidebarOptional` |
| Sidebar dock | `SidebarDock`, `SidebarDockBrand`, `SidebarDockNav`, `SidebarDockItem`, `SidebarDockToggle`, `SidebarDockBadge`, `SidebarDockWordmark`, `SidebarDockFooter`, `SidebarDockSwitcher`, `SidebarDockSwitcherItem`, `SidebarDockThemeToggle`, `SidebarDockViews`, `SidebarViewport`, `SidebarView`, `SidebarViewOutlet`, `SidebarViewSlot`, `useSidebarDockViews`, `useSidebarView` |
| Skeleton | `Skeleton` |
| Slider | `Slider` |
| Switch | `Switch`, `SwitchVisual` |
| Table | `Table`, `TableDensityProvider`, `TableHeader`, `TableBody`, `TableFooter`, `TableRow`, `TableHead`, `TableCell`, `TableCaption`, `TableSelectionCell`, `TableSortButton`, `TableCard`, `TableCardToolbar`, `TableCardSupportingContent`, `TableCardFooter`, `TableBulkBar`, `useTablePinning` |
| Data table | `DataTable`, `createDataTableColumnHelper`, `DataTableColumnDef`, `DataTableColumnMeta`, `DataTableProps` |
| Filters | `FilterBar`, `FilterBarField` |
| Tooltip | `Tooltip`, `TooltipProvider`, `TooltipTrigger`, `TooltipContent` |
| Provider & hooks | `UiProvider`, `UiPortal`, `useUi`, `useResolvedTheme`, `useIsMobile`, `usePointerSheen`, `useDebouncedCallback`, `cn` |

## Variants worth knowing

**`Avatar`**
`size`: `24` · `32` · `40` · `48` · `64` · `80` · `96`. The Figma
`64` variant intentionally renders at 56px. The legacy aliases `sm`, `default`,
and `lg` remain available and map to `24`, `32`, and `40` respectively. The
no-prop default remains 32px for compatibility.

`theme`: `green` · `yellow` · `orange` · `pink` · `red` · `purple` · `teal` ·
`blue` · `indigo` · `picture` · `empty`. Use `AvatarImage` for `picture`; the
`empty` theme renders the design-system silhouette instead of fallback text.
The default theme is `green`.

**`Button`**
`variant`: `default` · `accent-secondary` · `neutral-primary` · `secondary` ·
`destructive` · `outline` · `ghost` · `link`.
`size`: `default` · `xs` · `sm` · `lg` · `icon` · `icon-xs` · `icon-sm` · `icon-lg`.

**`LiquidButton`** — the glass treatment.
`theme`: `accent` · `primary` · `inverse`.
`size`: `default` · `sm` · `lg` · `icon` · `icon-sm` · `icon-lg`.

**Icons in buttons** — pass them through `icon` (before the label) and
`iconRight` (after), not through `children`:

```tsx
<Button icon={<IconBell />}>Alerts</Button>
<Button size="sm" iconRight={<IconArrowRight />}>Next</Button>
```

Both slots exist on `Button` and `LiquidButton`, and `IconButton` does the same
for its single child. The slot sets a real `size` prop on the icon (14 / 16 / 20
px by button size), and that prop is what selects the icon's optical master — at
16px and below the icons ship a purpose-drawn small master. An icon dropped into
`children` only gets a CSS `size-*` class: the box measures correctly while the
drawing inside is the 24px master shrunk down, with nothing to warn you. Set
`size` yourself to override (`icon={<IconBell size={24} />}`).

With `asChild`, `Slot` borrows the caller's element and keeps that element's own
children, so `icon` / `iconRight` are ignored — put the icon inside the child and
size it there.

**Data tables.** `TableCard` is the full Figma frame — toolbar, table, pagination
footer — in one card:

```tsx
<TableCard>
  <TableCard.Toolbar start={<><FilterButton /><SearchInput /></>} end={<ExportButton />} />
  <TableCard.SupportingContent><ActiveFilters /></TableCard.SupportingContent>
  <Table>…</Table>
  <TableCard.Footer><Pagination>…</Pagination></TableCard.Footer>
</TableCard>
```

`TableCard.SupportingContent` is a full-width slot with horizontal/bottom
spacing aligned to the toolbar. It adds no background or radius; the consumer
owns those surface choices.
`TableCard.Footer`, not `TableFooter` — `TableFooter` is the `<tfoot>` element
and lives inside the table.

Use `DataTable` when the screen needs complete data-grid behavior rather than
table markup alone. It integrates fixed left/right columns, keyboard and pointer
resizing, Shift-click multi-sort, client or controlled server pagination, row
selection, column visibility, and skeleton loading. It never fetches data.

```tsx
const helper = createDataTableColumnHelper<Event>()
const columns = helper.columns([
  helper.accessor('name', {
    header: 'Event name',
    size: 240,
    enableSorting: true,
    meta: { pinned: 'left' },
  }),
  helper.accessor('status', {
    header: 'Status',
    size: 140,
    meta: { pinned: 'right' },
  }),
])

<DataTable
  columns={columns}
  data={events}
  getRowId={event => String(event.id)}
  enableRowSelection
  showColumnVisibilityControl
  toolbarStart={<SearchInput variant="tiled" placeholder="Search" />}
/>
```

For server data, pass `manualPagination`, `manualSorting`, `rowCount`, controlled
`state={{ pagination, sorting }}`, and the matching `onPaginationChange` /
`onSortingChange` callbacks. Fetching remains in the consumer. Use `loading`
and optionally `skeletonRowCount` while the new page loads; the header, footer,
widths, and pinned geometry remain mounted.

**Pinned columns** are declared on the cells, never on `Table`:

```tsx
<TableHead pinned="left" style={{ width: 260 }}>Name</TableHead>
<TableCell pinned="left">{row.name}</TableCell>
```

`Table` measures the header widths itself and positions every pinned cell, so any
CSS width works (`%`, `auto`, px) and a body cell needs no index or width of its
own. The opaque background and the edge shadow appear only while that side still
has content scrolled out of view. Do not merge cells (`colSpan`) in the header row
of a table with pinned columns — the columns are matched by cell index.

`TableSelectionCell` renders `<th>` or `<td>` on its own depending on the section
it sits in, takes `indeterminate` for a partial selection, and stops the click from
reaching a row-level `onClick`. `TableSortButton` is stateless — pass `direction`
(`"asc" | "desc" | false`) and `align="end"` for right-aligned columns.

`TableBulkBar` floats above the page when `count > 0`; it stays mounted and inert
while hidden so it can animate out, and it holds the last non-zero count so the
label does not flash "0 selected" mid-animation. Its responsive layout ships in
the package CSS, so it does not depend on a Tailwind v3 host scanning package
source files.

**`Badge`**
`variant`: `default` · `neutral` · `inprogress` · `complete` · `warning` ·
`negative` · `destructive` · `secondary` · `outline` · `ghost` · `link`, plus a
boolean `elevated` that changes the surface treatment per variant.

The five status variants put the label in `content-primary` and the semantic
colour on the icon: the Figma pairing (`<sem>-primary` on `<sem>-secondary`)
only reaches 2.53–4.79:1 at the tag's 12px, so six of its eight light/dark
combinations failed WCAG 1.4.3. Pass an icon as the first child to keep the
state readable at a glance — see SKILL.md § "Contrast floors for the semantic
tokens".

**`Chip`** — `variant`: `flat` · `elevated`; boolean `selected`.

**`Alert`** — `variant`: `default` · `destructive`.

**`AiOrb`** — no variants. The VinUni AI sphere: a raster orb with an animated
light mesh layered on top in `mix-blend-mode: screen`. **Size comes from
`className`, not a prop** (`size-24` by default, i.e. 96px) — that is also what
lets a consumer *tween* it, which the assistant surfaces do when the orb flies
from the welcome screen into the conversation header. Decorative by default;
pass `alt` when it is the only thing naming the assistant. The mesh holds a
resting frame under `prefers-reduced-motion: reduce` rather than disappearing.

**`Input`** — `variant`: `line` · `secondary`; `sizing`: `fixed` · `auto`.
`secondary` is Figma's `tile-md` style: a `bg-tiled-md` fill with **no border**
at rest or disabled, and a 1px border only on hover / focus / error / positive.

**`SearchInput`** — `variant`: `floated` · `tiled`. `floated` supports `size`:
`small` · `medium` · `large`; `tiled` is the fixed 36px table-toolbar search
field.

**`AdvancedSelect`** — `mode="single"` uses `string | null`; `mode="multiple"`
uses `string[]`. The search box filters `items` itself, so a local list needs
nothing beyond `items`. Pass `shouldFilter={false}` **only** when the list
arrives already filtered — server-side search, or a controlled `inputValue`
whose `items` you narrow yourself — otherwise you get two filters fighting.
`isLoading`, `error`, `hasMore`, `onLoadMore`, and `onRetry` cover remote
collections, and the list is virtualized (React Aria `Virtualizer` +
`ListLayout`) at every size. For multiple async selection, keep chosen option
objects in `selectedOptions` so tags retain their labels when the current result
page no longer contains them. At most three tags are shown by default; change
`maxVisibleTags` when the field has more room.

For server-side search, fetch from `onSearch` rather than `onInputChange`:
`onSearch` is debounced (`searchDebounceMs`, default `300`), so an eight-letter
query fires one request instead of eight arriving out of order. It never fires on
mount, never repeats an unchanged query, and does not fire when picking an option
writes that option's label into the box. `onInputChange` still fires on every
keystroke — keep using it for a controlled `inputValue`. Pair `onSearch` with
`shouldFilter={false}`, since the server has already filtered.

```tsx
<AdvancedSelect
  items={results}
  shouldFilter={false}
  isLoading={loading}
  onSearch={(query) => fetchStudents(query)}
  searchDebounceMs={300}
/>
```

**Date pickers** — `DatePicker` (one day), `DateTimePicker` (day + time) and
`DateRangePicker` (a range, optionally with time) share one field, popover and
calendar (React Aria). Values come from `@internationalized/date`, never JS
`Date`:

| Component | Value | Build / serialize |
| --- | --- | --- |
| `DatePicker` | `CalendarDate` | `parseDate('2030-10-03')` / `.toString()` |
| `DateTimePicker` | `CalendarDateTime` (local wall time) or `ZonedDateTime` | `parseDateTime('2030-10-03T09:30')`, `parseZonedDateTime('…[Asia/Ho_Chi_Minh]')` |
| `DateRangePicker` | `{ start, end }` of `CalendarDate` | as `DatePicker` |
| `DateRangePicker granularity="minute"` | `{ start, end }` of `CalendarDateTime` / `ZonedDateTime` | as `DateTimePicker` |

- **Presets.** `presets` puts shortcut pills at the top of the popover —
  `[{ label: 'Last 7 days', value: () => ({ start, end }) }]`. Write `value` as a
  **function** so it is evaluated on click: a preset computed while building
  props freezes the day the page loaded, and a tab left open past midnight sends
  "Today" to yesterday. Picking one closes the popover, except on the
  time-enabled pickers, where the time still needs setting.

A `CalendarDate` carries no time and no time zone, so a day picked in Hanoi never
shifts when a UTC server reads it. `name` (or `startName` / `endName`) submits ISO
strings through a native form. `@internationalized/date` is already a dependency
of `@vinuni/ui`; add it to the app's own `package.json` when importing it directly
under pnpm's strict layout.

- **Time.** `DateTimePicker` defaults to `granularity="minute"` (`"hour"` ·
  `"second"` also valid); `DateRangePicker` turns time on when `granularity` is
  passed. The time is typed in the field or set in the time fields under the
  calendar; the popover stays open after a day is picked and closes on **Done**,
  Escape or an outside click — closing commits, filling `00:00` when no time was
  chosen. `hourCycle={12}` for AM/PM. Times always show leading zeros (`08:30`).
  The types are split on purpose: a `CalendarDateTime` value without
  `granularity`, or a `CalendarDate` in `DateTimePicker`, is a TypeScript error.
- Locale defaults to `en-GB` (matches Figma: `Mon`, `30/10/2030`, 24h time, week
  starts Monday). Pass `locale="vi-VN"` for Vietnamese month names, weekdays and
  error messages, plus `rangeSeparator="đến"`, `doneLabel`, `clearLabel`,
  `timeLabel` / `startTimeLabel` / `endTimeLabel` for the remaining English text.
- Constraints: `minValue`, `maxValue`, `isDateUnavailable` (struck through, not
  selectable), `allowsNonContiguousRanges` (range only). Out-of-bounds values and
  a range that ends before it starts — including the same day with an earlier
  end time — render the field in `error` state by themselves.
- Validation shows on commit (blur, calendar pick, form submit) by default, so a
  half-typed year never flashes red. Use `validationBehavior="aria"` for live
  validation. Pass `errorMessage` to override React Aria's localized messages.
- `isClearable` (default `true`) shows a clear button once a value exists; it is
  hidden when `isDisabled` or `isReadOnly`. `variant`: `line` · `secondary` (same
  as `Input`); `isValid` draws the positive state.
- Field width caps at 393px; a range **with time** caps at 480px because
  `03/10/2030, 09:00 to 08/10/2030, 17:00` does not fit 393. Narrower parents
  scroll the dates horizontally inside the field.
- `Calendar` / `RangeCalendar` render the same calendars inline, without a field.

**`Bubble`** — `variant`: `default` · `secondary` · `muted` · `tinted` ·
`outline` · `ghost` · `destructive` · `glass`; `align`: `start` · `end`.
`glass` is the frosted surface (`FloatedSurface`) for transcripts sitting on an
unpredictable backdrop — a photo, a video, a map. On a flat background the other
seven are cheaper and read better.

**`Message`** — `align`: `start` · `end`.

**`Marker`** — `variant`: `default` · `separator` · `border`.

**`MessageScrollerButton`** — `size`: `icon-xs` · `icon-sm` · `icon-lg` ·
`icon` (default `icon-sm`), plus `direction`: `start` · `end`. It sits on a
`FloatedPanel` glass surface, so there is **no `variant` prop** — the surface is
the only look it has.

## Chat surfaces

`Message` is the **layout of one turn**; the coloured surface is `Bubble`. They
are separate because one turn can hold several tiles — or none, when it holds an
image or a card — and they all still need to share one `max-w` and one aligned
edge.

```tsx
import {
  Avatar, AvatarFallback, Bubble, BubbleContent,
  Message, MessageAvatar, MessageContent, MessageFooter,
} from '@vinuni/ui'

<Message align="end">
  <MessageContent>
    <Bubble>
      <BubbleContent>Thanks!</BubbleContent>
    </Bubble>
    <MessageFooter>09:12</MessageFooter>
  </MessageContent>
</Message>
```

`align="end"` flips the whole row, so the avatar, the bubble and the footer all
move together — you never set `justify-end` yourself. `MessageAvatar` anchors to
the bottom of the turn and lifts itself by the footer's height when one is
present. `MessageHeader` and `MessageFooter` are padded to line up with the text
*inside* the bubble, not with the bubble's edge.

Set the surface on `Bubble`, not on `BubbleContent`: the wrapper paints every
tile inside it, so a turn with three tiles takes one `variant`. `BubbleContent`
accepts `asChild` when the tile itself must be a `button` or `a`; hover and
press then run through the same `::after` overlay `Button` uses, so the feedback
timing matches the rest of the library.

## Chat markers

`Marker` is the transcript's note about *itself* — a status line, a system note,
a dated divider. It is deliberately not a `Bubble`: no surface, no avatar,
because it belongs to nobody in the conversation.

```tsx
import { Marker, MarkerContent, MarkerIcon } from '@vinuni/ui'

<Marker role="status">
  <MarkerIcon><IconRotateArrow className="animate-spin" /></MarkerIcon>
  <MarkerContent shimmer>Đang suy nghĩ…</MarkerContent>
</Marker>

<Marker variant="separator">
  <MarkerContent>Hôm nay</MarkerContent>
</Marker>
```

Three things differ from the upstream shadcn `marker`:

- The polymorphic root is **`asChild`** (Radix `Slot`), not `render` — same as
  every other component here. Use it to get a real `<a>`/`<button>`; a `<div>`
  with `onClick` takes neither Tab nor Enter.
- Streaming text is the **`shimmer` prop on `MarkerContent`**, not a `shimmer`
  utility class: this package does not ship the `shadcn` utility layer. The
  effect lives in `motion.css`, and `prefers-reduced-motion: reduce` turns it
  off completely — a ~0.5 Hz loop is exactly what that setting is for. Keep a
  spinner in `MarkerIcon` so the running state survives without it.
- `MarkerIcon` is always `aria-hidden`; `MarkerContent` carries the meaning. An
  icon-only marker needs `aria-label` on `Marker` itself.

Set `role="status"` on a running marker so the update is announced. Do **not**
set `role="separator"` on a labelled divider: a separator takes its name from
`aria-label` and treats its contents as presentational, so the visible label
would be swallowed. The rules are `::before`/`::after`, already invisible to
assistive tech.

## Chat scroller

`MessageScroller` is the transcript frame: turn anchoring, follow-the-live-edge
while streaming, and scroll-position preservation when older history is
prepended. State lives in `MessageScrollerProvider`, so it wraps the frame.

```tsx
<MessageScrollerProvider autoScroll defaultScrollPosition="end">
  <MessageScroller>
    <MessageScrollerViewport>
      <MessageScrollerContent>
        {turns.map(turn => (
          <MessageScrollerItem
            key={turn.id}
            messageId={turn.id}
            scrollAnchor={turn.role === 'user'}
          >
            <Message>…</Message>
          </MessageScrollerItem>
        ))}
      </MessageScrollerContent>
    </MessageScrollerViewport>
    <MessageScrollerButton />
  </MessageScroller>
</MessageScrollerProvider>
```

`scrollAnchor` marks a **turn boundary** — set it on the user's message, not on
every row, or the transcript re-anchors on each token that streams in.
`autoScroll` only follows the live edge while the reader is already at the
bottom; scroll up to re-read and the transcript holds still, with the scroll
button appearing as the way back.

`MessageScroller` renders its own top and bottom `ScrollEdgeEffect` overlays and
shows each one only when that side still has content off-screen. Pass
`edgeTheme` (`grounded` · `elevated` · `mortared`) to match whatever background
the frame sits on — a mismatch shows as a coloured band across the edge.

`useMessageScroller()` returns `scrollToEnd` / `scrollToStart` /
`scrollToMessage`; `useMessageScrollerScrollable()` and
`useMessageScrollerVisibility()` report which edges can scroll and which rows
are on screen. All three must be called inside the provider.

## Fading a scroll edge: two mechanisms, pick by background

`<ScrollEdgeEffect>` **paints** a gradient of the background colour over the
content, so it has to know that colour — pass `edge`, `theme`
(`grounded` · `elevated` · `mortared`) or override `--scroll-edge-effect-fill`.
A mismatch shows as a coloured band across the edge. Use it on opaque surfaces,
and when content must be hidden completely as it slides under a header.

`scroll-fade` is a CSS utility that **dissolves** the content with `mask-image`,
so it adapts to any background with no configuration — including glass
(`FloatedPanel`, where no fill colour matches and a painted gradient leaves a
visible seam). Put it on the element that scrolls:

```tsx
<div className="scroll-fade scrollbar-slim scrollbar-stable max-h-72 overflow-y-auto">…</div>
```

It tracks scroll position through CSS scroll-driven animations — no listener, no
JS: crisp top and faded bottom at rest, both edges faded mid-scroll, crisp bottom
at the end, and **no fade at all when the content does not overflow**. Browsers
without scroll-driven animations fall back to a static fade on both edges. Size
the fade with `--vinui-scroll-fade-size` (default `1.5rem`).

### Scrollbar utilities

| Utility | Thumb | Gutter |
| --- | --- | --- |
| `scrollbar-slim` | visible, themed, 8px | taken (only while overflowing) |
| `scrollbar-quiet` | transparent | taken |
| `no-scrollbar` | hidden | none |
| `scrollbar-stable` | — | always reserved |

**On macOS the default scrollbar is an overlay: 0px wide, drawn over the content
and hidden a moment after you stop scrolling.** So a plain `overflow-y-auto`
looks like it has no scrollbar at all on a Mac, even though nothing is hiding it.
`scrollbar-slim` escapes that by giving `::-webkit-scrollbar` an explicit width,
which switches the browser back to a classic, always-visible scrollbar. It
deliberately declares `scrollbar-width` / `scrollbar-color` **only** inside a
Firefox-only `@supports` block: in Chromium the mere presence of either property
makes the whole `::-webkit-scrollbar` block be ignored, which puts macOS straight
back on the auto-hiding overlay.

Pair `scrollbar-slim` with `scrollbar-stable`, or the list shifts 8px sideways
the moment a filter makes it stop overflowing.

`scroll-fade` and a visible scrollbar coexist without extra work: the fade tracks
the scroll position, so whichever edge the thumb is parked at is the crisp one.

## Questionnaire

A multi-step form: one question per screen, with progress, navigation and
optional keyboard shortcuts. `items` declares the flow up front — the navigation
needs to know the total and each question's choices before the step renders.

```tsx
<Questionnaire
  items={[
    { name: 'format', required: true, choices: [{ value: 'online' }, { value: 'campus' }] },
    { name: 'comment' },
  ]}
  shortcuts="letters"
  onSubmit={event => { event.preventDefault(); /* new FormData(event.currentTarget) */ }}
>
  <QuestionnaireProgress />
  <QuestionnaireItem name="format" required>
    <QuestionnaireTitle>How do you want to study?</QuestionnaireTitle>
    <QuestionnaireDescription>Pick one.</QuestionnaireDescription>
    <QuestionnaireChoices>
      <QuestionnaireChoice value="online">
        Fully online
        <QuestionnaireChoiceDescription>No campus days.</QuestionnaireChoiceDescription>
      </QuestionnaireChoice>
      <QuestionnaireChoice value="campus">On campus</QuestionnaireChoice>
    </QuestionnaireChoices>
    <QuestionnaireError>Pick one to continue.</QuestionnaireError>
  </QuestionnaireItem>
  <QuestionnaireActions>
    <QuestionnairePrevious />
    <QuestionnaireSkip />
    <QuestionnaireNext />
    <QuestionnaireSubmit />
  </QuestionnaireActions>
</Questionnaire>
```

It renders a real `<form>` of real `<input>`s, so `FormData`, native validation
and screen readers all work without extra wiring. `multiple` on an item turns
its choices into checkboxes; `required` blocks `Next` until the question is
answered; `QuestionnaireSkip` only appears on questions that are not required.

**Steps stay mounted.** Inactive questions keep their DOM and are marked
`hidden`, which is what lets the step transition run from CSS alone. Do not
conditionally render the items yourself — you lose both the animation and the
answers.

`Next` and `Submit` share the same grid cell on purpose, so the last step swaps
the label in place instead of shifting the row. The four navigation buttons take
`Button`'s `variant` and `size`. Default labels are Vietnamese (`Quay lại`,
`Bỏ qua`, `Tiếp tục`, `Gửi`) — pass children to override.

## Form fields have one state machine

All field-shaped components resolve to a single `data-field-state` attribute
rather than each carrying their own error/valid styling. The six Figma states
collapse into four values: `default`, `error`, `positive`, `disable`.

```tsx
import { Input, resolveFieldState, isInvalid } from '@vinuni/ui'

<Input aria-invalid={hasError} disabled={busy} />
```

`aria-invalid` is honoured in its full HTML form — `"grammar"` and `"spelling"`
count as invalid, only `false`/`"false"`/absent do not. When building a new
field-like component, import `inputVariants` and `resolveFieldState` instead of
copying classes; that is what keeps `Select`, `Textarea` and `SearchInput`
visually identical to `Input`.

The background comes from `variant`, which is Figma's `style` axis. `line` draws
a border and nothing else; `secondary` is Figma's `tile-md` — the fill carries
the shape, so there is no border at rest or disabled, only on hover, focus,
error and positive. The border box is still there, painted transparent, so
nothing shifts by a pixel when hover paints it in. Figma's third style, `card`
(a `bg-card` fill behind a 4px backdrop blur, inside a 2px border), is **not
built**: its 2px border changes the inner height, so it cannot join
`inputVariants` without moving every other field. It also has no `disable`
state in Figma.

`SelectTrigger` is the one deliberate exception, and the Figma component set
(`select button`) is what says so: `pl-16 pr-12` rather than `px-16`, a chevron
of 20px at the default size and 16px at `size="sm"`, 14/20 text at `sm`, and
disabled text at `content-tertiary` where an `Input` uses `content-disable`. It
also takes the accent border while its panel is open, because clicking to open
never fires `:focus-visible`. Everything else — hover, focus ring, the
`positive` border — still comes from `inputVariants`, so a select does not drift
from the inputs beside it.

A leading icon goes in front of `<SelectValue>` and needs its `size` prop set by
hand — 24 at the default size, 20 at `sm` — for the same optical-master reason
the button icon slots exist (see Icons). Without it the CSS box is right and the
drawing inside is the 24px master shrunk.

`size` on the trigger also sizes the menu: `SelectItem` drops from 44px rows
with 16/24 text and a 24px radio to 36px rows with 14/20 text and a 20px radio,
matching Figma's two `cell item` sizes. You set it once, on `<SelectTrigger>` —
the root carries it across to the items, since trigger and content are siblings
rather than parent and child.

**`SelectionIndicator`** — `shape`: `checkbox` · `radio`; `size`: `md` (default,
24px) · `sm` (20px). It is decorative: the row around it already carries
`role="option"` and `aria-selected`, so it never renders a real control.

## File upload

`FileUploadField` uploads on drop and knows nothing about your form library.
Wire the transport once at the app root, then each field only names its module:

```tsx
import {
  createFileManagerClient, FileManagerProvider, FileUploadField, UiProvider,
} from '@vinuni/ui'

const fileManager = createFileManagerClient({
  baseUrl: import.meta.env.VITE_FILE_MANAGER_API_URL,
  httpClient: myAuthedFetch,   // or: getToken: () => auth.accessToken
})

<UiProvider>
  <FileManagerProvider client={fileManager}>…</FileManagerProvider>
</UiProvider>
```

```tsx
<FileUploadField
  module="rms-human-ethics"
  multiple
  maxFiles={3}
  maxSize={20 * 1024 * 1024}
  accept={{ 'application/pdf': ['.pdf'] }}
  value={value}
  onChange={onChange}
/>
```

`FileManagerProvider` is independent of `UiProvider` — it does not replace it,
and an app that never uploads does not need it.

**The value only ever holds files that finished uploading.** `value` is
`UploadedFile[]` when `multiple`, `UploadedFile | null` otherwise, and
`onChange` fires only once storage returns a `fileId`. Files still in flight
live in the component's own state, so submitting mid-upload cannot put a
half-written file in your payload. `multiple` discriminates the props type, so
`value` can never disagree with `onChange`.

Controlled when you pass `value`, uncontrolled when you don't — same shape as
`UiProvider`'s `theme` / `defaultTheme`. Pass `defaultValue` to seed the
uncontrolled list. Note `value` counts as *passed* whenever it is not
`undefined`: `null` and `[]` are real values and do put the field in controlled
mode, so a controlled field must keep echoing `onChange` back into `value` or
uploaded files will not appear.

Two extension points: `renderFileActions(file)` adds per-row controls (a preview
or download button — the package deliberately ships no previewer), and `labels`
takes translated strings, set globally on the provider and overridden per field.

For a different backend, skip `createFileManagerClient` and pass any object with
`upload(file, ctx)` as `client`. For a different UI, take `useFileUpload()` and
render it yourself.

## Composition patterns

**Scroll indicator** — every item maps to a real section `id`. Omit
`scrollContainerRef` for page scrolling; pass it for a dialog, panel, or other
overflow container. Hover or keyboard focus opens the section list; pointer
click does not toggle it. `position="left"` (default) opens the menu to the
right of the rail, while `position="right"` mirrors the component. `activeId`
makes the current section controlled; `onActiveChange` still reports the
section observed at the reading line.

```tsx
const scroller = useRef<HTMLDivElement>(null)
const sections = [
  { id: 'overview', label: 'Overview' },
  { id: 'citations', label: 'Citations' },
]

<div ref={scroller} className="overflow-y-auto">
  <section id="overview">…</section>
  <section id="citations">…</section>
</div>
<ScrollIndicator
  label="Content sections"
  position="left"
  sections={sections}
  scrollContainerRef={scroller}
/>
```

**Dialog** — `DialogHeader` and the optional `DialogSubHeader` stay fixed in the
dialog's flex layout while the body scrolls. Put the subheader and one body
wrapper as **siblings** of the header. `DialogSubHeader` accepts controls such as
`Input`, `Select`, or filters and moves the top `ScrollEdgeEffect` below those
controls:

```tsx
<DialogContent>
  <DialogHeader>
    <DialogTitle>Confirm action</DialogTitle>
  </DialogHeader>
  <DialogSubHeader>
    <Input placeholder="Search" />
  </DialogSubHeader>
  <div tabIndex={0} role="region" aria-label="Dialog content">
    <DialogDescription>This cannot be undone.</DialogDescription>
    {/* Long body content */}
  </div>
  <DialogFooter>
    <Button variant="destructive">Delete</Button>
  </DialogFooter>
</DialogContent>
```

**Dialog full screen** — `expandable` on `DialogContent` adds a top-left
toggle (`Enter full screen` / `Exit full screen`) that grows the dialog to the
viewport: no radius, no border, `100dvh` tall. Uncontrolled state starts from
`defaultFullScreen` and resets when the dialog closes; pass `fullScreen` +
`onFullScreenChange` to control it (or to force full screen without a toggle).
The content carries `data-fullscreen="true|false"`, and full-screen sizing beats
a consumer size class such as `h-[480px]`. The resize is animated with
`clip-path` + `translate` (no layout per frame, reversible mid-flight, skipped
under `prefers-reduced-motion`); `data-fullscreen` stays `"true"` until a
collapse finishes, so key your own full-screen styles off it rather than off
`fullScreen`:

```tsx
<DialogContent expandable onFullScreenChange={(next) => track(next)}>
  <DialogHeader>
    <DialogTitle>Enrollment report</DialogTitle>
  </DialogHeader>
  <div tabIndex={0} role="region" aria-label="Report">{/* … */}</div>
</DialogContent>
```

**Async confirm** — `confirmLoading` on `ConfirmDialogContent` drives the whole
asynchronous state from one flag: the confirm button spins and stops closing the
dialog, the cancel button is disabled, and Escape / outside-click / the X button
stop dismissing it (that last part is `busy` on `DialogContent`, available on its
own for any dialog wrapping an async form). Close it yourself when the work
finishes — usually `setOpen(false)` in the same handler that raised the flag. An
explicit `DialogClose`, such as the cancel button, still closes, so this is not a
trap the user cannot leave.

Declaring `confirmLoading` at all — even as `false` — switches the confirm button
into asynchronous mode. That is deliberate: at the moment of the click the flag is
still `false` (it only flips on the next render), so a button that decided by the
live value would close the dialog before the spinner could exist.

```tsx
<ConfirmDialogContent confirmLoading={saving}>
  {/* … */}
  <ConfirmDialogActions>
    <ConfirmDialogAction
      onClick={async () => {
        setSaving(true)
        await remove(id)
        setSaving(false)
        setOpen(false)
      }}
    >
      Delete
    </ConfirmDialogAction>
    <ConfirmDialogCancel>Back</ConfirmDialogCancel>
  </ConfirmDialogActions>
</ConfirmDialogContent>
```

**Drawer full screen** — `fullScreen` on `DrawerContent` drops the default cap
(`80vh` tall for top/bottom, `max-w-sm` wide for left/right) along whichever axis
the drawer opens, for long data forms that a 200px scroll box makes unusable on a
phone. `busy` is the drawer's version of the dialog's: it blocks Escape, outside
clicks, and vaul's drag-to-dismiss while a save is in flight.

**Command** — do not wrap `CommandItem`s in a plain `<div>`. When filtering,
cmdk reorders results by moving DOM nodes and assumes an ungrouped item's
`parentElement` is the list sizer; an extra wrapper makes it call
`appendChild(null)` and tear down the React tree. Use `CommandGroup` or nothing.

**Radix state** — target `data-[state=open]`, never `data-open:`. The latter
silently never matches.

**Overlays** — `Dialog`, `Drawer`, `DropdownMenu`, `Popover`, `Select`, `Sheet`,
`Tooltip` and the Sonner `Toaster` already portal into the provider. Render
`<Toaster />` once inside `UiProvider` and call `messageToast(...)` from
anywhere beneath it.

**Sidebar** — `SidebarProvider` is a separate provider that owns collapse state;
it nests inside `UiProvider`, not instead of it.

For a collapsible navigation section, compose `SidebarCollapsibleGroup`,
`SidebarGroupTrigger`, and `SidebarGroupCollapsibleContent`, then render regular
`SidebarMenuButton` cells inside. Each group opens independently and child rows
stay on the same grid as the rest of the sidebar:

```tsx
<SidebarCollapsibleGroup>
  <SidebarGroupTrigger>Recent conversations</SidebarGroupTrigger>
  <SidebarGroupCollapsibleContent>
    <SidebarMenu>
      <SidebarMenuItem>
        <SidebarMenuButton>Admissions overview</SidebarMenuButton>
      </SidebarMenuItem>
    </SidebarMenu>
  </SidebarGroupCollapsibleContent>
</SidebarCollapsibleGroup>
```

`SidebarMenuSub` remains available for compatibility and no longer draws a
tree rail. Prefer the collapsible-group composition for new navigation.

**Sidebar dock** — the 56px brand rail that sits beside `Sidebar`. Render it as a
sibling of `Sidebar` inside `SidebarProvider`; the panel offsets itself
automatically. Use `collapsible="offcanvas"` so `SidebarDockToggle` hides the
panel while the rail stays put.

`SidebarDockViews` turns rail buttons into panel view switchers: give a
`SidebarDockItem` a `view` prop and pair it with a `SidebarView` of the same
`value` inside `SidebarViewport`. Every view stays mounted (hidden ones are
`inert`) so the blur/scale/fade transition can be interrupted mid-flight.

```tsx
<SidebarProvider>
  <SidebarDockViews>
    <SidebarDock>
      <SidebarDockBrand />
      <SidebarDockNav>
        <SidebarDockToggle />
        <SidebarDockItem view="search" tooltip="Search"><IconMagnifyingglass /></SidebarDockItem>
      </SidebarDockNav>
      <SidebarDockWordmark />
      <SidebarDockFooter><SidebarDockThemeToggle /></SidebarDockFooter>
    </SidebarDock>
    <Sidebar collapsible="offcanvas">
      <SidebarViewport>
        <SidebarView value="nav">…</SidebarView>
        <SidebarView value="search">…</SidebarView>
        <SidebarViewOutlet />
      </SidebarViewport>
    </Sidebar>
    <SidebarInset>…</SidebarInset>
  </SidebarDockViews>
</SidebarProvider>
```

Wrap `SidebarInset` with `SidebarDockViews` too, as above — that is what lets page
content reach the panel. `SidebarDockViews` renders no DOM node, so the layout is
unchanged, but it must stay *inside* `SidebarProvider` because it needs the
panel's open state.

**Panels owned by a page.** For a panel that only exists while one page is on
screen — a filter form for a list, a table of contents for a document — put a
`SidebarViewOutlet` in the viewport and render `SidebarViewSlot` from the page.
The slot portals into the outlet, and the panel falls back to the base view when
the page unmounts. `useSidebarView(value)` gives the page its own show/hide
button:

```tsx
function StudentListPage() {
  const filter = useSidebarView('students-filter')
  const [criteria, setCriteria] = React.useState(EMPTY) // state lives here, not in the slot

  return (
    <>
      <SidebarViewSlot value="students-filter">
        <StudentFilterForm value={criteria} onChange={setCriteria} />
      </SidebarViewSlot>
      <Button onClick={filter.toggle} aria-pressed={filter.visible}>Filters</Button>
    </>
  )
}
```

Keep the panel's state in the page, never inside the slot's children: on mobile
`Sidebar` renders as a `Sheet` and Radix unmounts its content when closed, so
state held inside the slot is lost every time the panel closes. Desktop
`offcanvas` only slides out of view, which is why this never shows up in
development.

`useSidebarView().toggle` undoes exactly what `show()` did: it restores the view
that was showing before, and the panel's open state along with it. So a panel that
was open on the nav list goes back to the nav list rather than closing — closing it
would take the whole navigation away, not just put the filter back. Call `hide()`
when you really do want the panel closed. A rail `SidebarDockItem` differs again:
it always returns to `baseValue`.

Only one `SidebarViewSlot` may claim a given `value` at a time — duplicates log a
warning and produce colliding ids.

Triggers outside `SidebarDockViews` are still possible: pass `value` /
`onValueChange` and drive the view from your own store or the URL.

`SidebarDockThemeToggle` calls `useUi().setTheme`. If your `UiProvider` is
controlled (you pass a `theme` prop), you must also wire `onThemeChange` back
into that prop — otherwise `setTheme` only fires the callback and the toggle
looks dead. The rail is a permanently dark surface: it keeps the same blue
gradient in both themes.

**Table** — `<TableDensityProvider density={…}>` sets density for a whole
subtree instead of passing a prop to every cell.

## Icons

```tsx
import { IconCheck, IconPlus, FileTypeIcon, MaskIcon } from '@vinuni/ui'

<IconCheck className="size-4" />
<FileTypeIcon type="pdf" />
```

Each `Icon*` carries two masters: a purpose-drawn 16px glyph used at
`size <= 16`, and a 24px master scaled otherwise. Sizes taken from Figma are the
**frame**, not the glyph — read the inner vector's `inset-[…%]` and multiply out
before choosing a `size-*`.

**Micro motion (opt in)** — all generated `Icon*` components accept
`animate?: boolean` (default `false`) and `active?: boolean` (default `false`).

```tsx
<Button icon={<IconBell animate />}>Notifications</Button>
<IconButton label="Favourite" aria-pressed={saved} onClick={() => setSaved(!saved)}>
  <IconHeart animate active={saved} />
</IconButton>
<IconStar animate={false} />
```

Hovering the icon or its containing button/link/tab/menu item plays one short
animation; press adds subtle compression (also on touch). `active` plays a
single activation accent, including when mounted active; toggle it false →
true to replay. It does not set ARIA selection state for the containing control.
All 205 shipped icons have an explicit assignment across 23 semantic motion
profiles (navigation, send, books, chat, tools, blink, sport, confirmation, etc.).
Custom icons made with `createIcon` use a gentle pop when their name is unknown.
`Foundations/Icons/Animated Gallery` previews every icon at 16/24px. Hover requires a fine pointer with hover support.
Disabled/inert ancestors suppress motion, as does `prefers-reduced-motion`.
For a custom trigger wrapper, add `data-icon-trigger` to its element.
The CSS ships in `styles.css` and standalone `motion.css`, scoped to `UiProvider`.
No animation runtime is required. This animates existing filled SVG geometry,
not path morphing; `MaskIcon` and raster `FileTypeIcon` do not expose these props.

`FileTypeIcon` renders full-colour raster badges for 8 file types (`pdf`, `jpg`,
`jpeg`, `png`, `csv`, `msword`, `msexcel`, `mspowerpoint`), inlined as base64 so
no asset-loader config is needed.

## Design resources

Resource illustrations are exported from Figma and bundled with the package, so
they do not depend on expiring Figma URLs. Each resource accepts `className` and
an optional `alt`; pass `alt=""` when it is decorative (the default for college
ribbons).

```tsx
import {
  CollegeRibbonCas,
  LecxeEmojiSmiling,
  LecxeEmptyNoData,
} from '@vinuni/ui'

<CollegeRibbonCas />
<LecxeEmojiSmiling alt="Smiling" />
<LecxeEmptyNoData />
```

For a one-off vector outside the curated set, use `<MaskIcon>` (CSS mask +
`currentColor`) so it follows the theme. An `<img>` or an SVG with baked fills
will not.
