# Setup, hosting, and distribution

## Installing

`@vinuni/ui` is published to VinUni's private JFrog registry, **not** npmjs.org.
Point the `@vinuni` scope at it in a committed `.npmrc` at the repo root:

```
@vinuni:registry=https://jfrog.vinsmartfuture.tech/artifactory/api/npm/vsf-qtvhgd-vinuni/
```

That file carries no credential and must never carry one. Authentication lives
in each developer's `~/.npmrc`:

```
//jfrog.vinsmartfuture.tech/artifactory/api/npm/vsf-qtvhgd-vinuni/:_authToken=<token>
```

Tokens come from <https://jfrog.vinsmartfuture.tech> → *Edit Profile* →
*Generate an Identity Token*, and need **Read** on `vsf-qtvhgd-vinuni`.

```bash
npm install @vinuni/ui         # newest release (dist-tag `latest`)
```

There is only one release channel — every published version is a stable release
under `latest`. There is no `@dev` or `@sit` tag.

Radix, cmdk, vaul, tailwind-merge, `@shadcn/react` and friends are
`dependencies` of the package, so nothing else needs installing. The only host
requirement is the peer: `react` and `react-dom` at `>=18.2.0 <20`.

`@shadcn/react` is the headless engine behind `Questionnaire` and
`MessageScroller`. It ships ESM-only and is imported by subpath
(`@shadcn/react/questionnaire`), which matters for a host that still bundles
CommonJS — if your bundler cannot resolve it, add it to the transpile/optimize
allowlist rather than aliasing it away.

**It declares `react >= 19`**, which is narrower than `@vinuni/ui`'s own peer
range. On a React 18 app `npm install` reports a peer conflict even if you never
import those two components, and the components genuinely need 19 (they pass
`ref` through props). Upgrade to React 19, or install with `--legacy-peer-deps`
and avoid `Questionnaire` / `MessageScroller`.

Pin `^x.y.z` in production. The `dev` tag is
`<version>-dev.<pipeline-iid>.<short-sha>` and is republished on every push to
`develop` — fine for trying an unreleased component, wrong for a long-lived pin.

## Entry points

| Import | Contents |
| --- | --- |
| `@vinuni/ui` | Barrel — components, hooks, types |
| `@vinuni/ui/styles.css` | All runtime CSS (motion included) |
| `@vinuni/ui/tokens.css` | Only the `--ds-*` variables |
| `@vinuni/ui/tailwind-theme.css` | Token aliases for a Tailwind v4 host |
| `@vinuni/ui/motion.css` | Motion only, when not using `styles.css` |
| `@vinuni/ui/colors` | Color tokens as JavaScript values |
| `@vinuni/ui/provider`, `/utils`, `/hooks/*` | Deep imports |
| `@vinuni/ui/button` | Per-component deep import |

The build is ES-only with `preserveModules`, so the barrel tree-shakes; deep
imports are for constraining what a module can reach, not for bundle size.

## Colors in JavaScript

Two exports, because the two use cases need different values. Picking the wrong
one fails silently — nothing throws, the color just doesn't appear.

```tsx
import { colors, colorValues, useColorValues } from '@vinuni/ui'
```

**`colors` — `var()` references.** For inline styles and dynamic values inside
the provider. Follows the theme automatically, since the browser resolves the
variable at render time.

```tsx
<div style={{ color: colors.contentPrimary }} />   // "var(--ds-content-primary)"
```

These are only meaningful **inside** the provider's `[data-vinuni-ui]` element.
Outside it the variable does not exist and the color falls back to whatever is
inherited, with no error.

**`colorValues` — real color values**, split by mode, for anything that does not
understand `var()`: Ant Design's `ConfigProvider`, chart libraries, canvas.

```tsx
colorValues.light.accentPrimary   // "#134d8b"
colorValues.dark.bgMortared       // "#232529"
```

`useColorValues()` returns the table for the theme currently in effect, so a
theme switch re-renders the consumer. It does not require the provider — without
one it falls back to `light`.

```tsx
import { ConfigProvider } from 'antd'
import { useColorValues } from '@vinuni/ui'

function AntdTheme({ children }: { children: React.ReactNode }) {
  const c = useColorValues()
  return (
    <ConfigProvider theme={{ token: { colorPrimary: c.accentPrimary } }}>
      {children}
    </ConfigProvider>
  )
}
```

Antd popups render in a portal outside `[data-vinuni-ui]`, which is exactly why
`ConfigProvider` needs `colorValues` and not `colors`.

Token names are the `--ds-*` names in camelCase: `--ds-bg-tiled-sm` →
`bgTiledSm`. `ColorToken` is the union of valid names. Tokens Figma has retired
are absent from these exports even though they still emit CSS.

## Coexisting with another design system

The package is built to sit next to something else. What breaks that is almost
always **cascade layers**, not specificity.

All package CSS is Tailwind v4 output, which lives inside
`@layer theme / base / components / utilities`. Per the CSS cascade, an
**unlayered** declaration beats **any** layered one no matter how specific each
side is. So a plain element reset from another library wins over every package
utility, and reordering imports does not help.

### Ant Design

`antd/dist/reset.css` is unlayered. Its element rules
(`h1..h6 { margin-bottom: .5em; font-weight: 500 }`, `p`/`ul`/`ol`
`{ margin-bottom: 1em }`, `button, input, select, textarea
{ font-family: inherit; line-height: inherit; margin: 0 }`,
`html { font-family: sans-serif; line-height: 1.15 }`) will override package
components. Import the reset into a named layer registered first instead:

```css
/* antd-reset.css */
@import "antd/dist/reset.css" layer(antd-reset);
```

```tsx
import './antd-reset.css'        // registers the layer first → lowest priority
import '@vinuni/ui/styles.css'
import './app.css'
```

A `@layer` statement is allowed before `@import`, and Vite's postcss-import
inlines `layer()` correctly. Verify by checking the emitted CSS begins with
`@layer antd-reset{…}` before Tailwind's `@layer properties/theme/base/…`.

Ant Design's own component styles are injected at runtime by cssinjs and are
also unlayered. They are `.ant-*`-scoped so they rarely collide, but
`<StyleProvider layer>` from `@ant-design/cssinjs` puts them in a layer too if
you want the guarantee.

### Tailwind v3 host

Nothing to configure. The package ships prebuilt, scoped CSS — do not add
`node_modules/@vinuni/ui` to the host's `content` globs, do not add a prefix.
The host's `:root`, `.dark`, preflight and keyframes are left untouched.

### Tailwind v4 host

Import the package stylesheet in application code before the host's Tailwind
entry. Only if the host itself authors `ds-*` utilities
(`bg-ds-bg-grounded`, `p-ds-sp-16`, `rounded-ds-rd-primary`) does it also need:

```css
@import "@vinuni/ui/tokens.css";
@import "@vinuni/ui/tailwind-theme.css";
```

`tailwind-theme.css` only registers aliases so Tailwind emits the matching
utilities; it adds no runtime style. The package's own components never need it.

## Fonts

Defaults are the design's own faces: `Geist Variable`, `Merriweather Variable`,
`Roboto Slab Variable`. Override inside the scope through the three hooks —
never by setting `--font-sans`, which is derived from the hooks and would become
self-referential:

```tsx
<UiProvider
  style={{
    '--vinuni-font-sans': "'Inter Variable', Inter, sans-serif",
    '--vinuni-font-heading': "'Inter Variable', Inter, sans-serif",
    '--vinuni-font-serif': "'Inter Variable', Inter, sans-serif",
    fontFamily: "'Inter Variable', Inter, sans-serif",
  } as React.CSSProperties}
>
```

The bare `fontFamily` matters: text without an explicit `font-*` class inherits,
and 26 of the 49 components deliberately do not set one.

**The matching trap:** any element *inside* the scope that re-declares
`font-family` — a host layout wrapper, an app shell class — becomes the nearest
ancestor for everything below it and silently replaces the design font for every
inheriting component. If some components show the right font and others do not,
look for such a wrapper before suspecting the package. Also check that the
declared family name is the one the font package actually registers:
`@fontsource-variable/inter` registers `'Inter Variable'`, not `'Inter'`.

## Docker and CI

The usual failure: developer machines work because of `~/.npmrc`; containers
have nothing and `npm ci` returns `E401`.

```dockerfile
FROM node:22-alpine AS dependencies
WORKDIR /app
ARG JFROG_NPM_TOKEN
COPY package.json package-lock.json .npmrc ./
RUN if [ -z "${JFROG_NPM_TOKEN}" ]; then \
      echo "Missing build-arg JFROG_NPM_TOKEN — npm ci will 401 on @vinuni/*." >&2; \
      exit 1; \
    fi; \
    printf '//jfrog.vinsmartfuture.tech/artifactory/api/npm/vsf-qtvhgd-vinuni/:_authToken=%s\n' \
      "${JFROG_NPM_TOKEN}" >> .npmrc \
    && npm ci \
    && rm -f .npmrc
```

Write and delete the token in the **same `RUN`**. Split across two layers, the
token stays readable in the intermediate layer via `docker history` even though
a later layer removed the file. Also confirm `.dockerignore` does not exclude
`.npmrc`, or the `COPY` fails.

GitLab CI must pass the token down as a build arg:

```yaml
- component: gitlab.vinsmartfuture.tech/shared/vsf-ptnt/centralize-ci-templates/dockerize@v2.3.0
  inputs:
    build_args: "--opt build-arg:JFROG_NPM_TOKEN=${JFROG_NPM_TOKEN}"
```

`build_args` is a **component input**, settable only where the `include` is
declared. If a shared template in `gitops-dev` does not pass it, that is where
the fix goes — a consuming repo cannot override it.

Jobs that run `npm ci` outside Docker (test, coverage, lint) need an `.npmrc`
with a token too: build it in `before_script`, delete it in `after_script`.

## Registry troubleshooting

| Symptom | Cause |
| --- | --- |
| `404 Not Found - GET https://registry.npmjs.org/@vinuni%2fui` | No `@vinuni:registry=…` line; npm is looking at npmjs.org |
| `npm error code E401` | Missing, wrong, or expired token. Check with `npm whoami --registry=…` |
| `npm error code E403` | Token authenticates but lacks permission on `vsf-qtvhgd-vinuni` |
| `E401` only inside Docker/CI | The container has no `~/.npmrc` — see above |
